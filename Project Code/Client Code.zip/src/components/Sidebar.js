import React, { useEffect, useState } from 'react';
import { FaHome, FaPlusCircle, FaStickyNote, FaSignOutAlt } from 'react-icons/fa';
import { AiFillEdit, AiOutlineDelete } from 'react-icons/ai';
import { FaEye } from 'react-icons/fa';
import { RiVideoAddLine,RiVideoAddFill } from "react-icons/ri";
import {CgNotes} from "react-icons/cg"
import { useNavigate } from 'react-router-dom';
import './Sidebar.css';
import AddMeeting from './AddMeeting';
import Note from './Note';


const Sidebar = (props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showNote, setShowNote] = useState(false);
  const [notes,setNotes] = useState('');
  const [name,setMail] = useState('');
  const [error,setError] = useState('');
  const [check1,setCheck1] = useState('right-input');
  const [check2,setCheck2] = useState('right-input');
  const [isnotes,setIsNotes] = useState(false);
  const [ncards,setNCards] = useState([]);
  const [title,setTitle] = useState('');
  const [Newtitle,setNewTitle] = useState('');
  const [NewNotes,setNewNotes] = useState('');
  const [content,setContent] = useState('');
  const [bigNotes,setBigNotes] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const navigate = useNavigate();
  const StoredData = localStorage.getItem("user");
  const user = JSON.parse(StoredData);
  const email=user.email;
  const handleEdit = () => {
    setIsEditing(true);
    setNewTitle(title);
    setNewNotes(content);
  };
  
  
  const handleNotes = (e) => {

    setNotes(e.target.value);
  }
  const handleMail = (e) => {

    setMail(e.target.value);
  }
  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const handleAddClick = () => {
    setShowAddForm(!showAddForm);
    setShowNote(false); 
  };

  const AddNotes = async() => {

    if(notes.trim() === ''){

      setError('please write something to save');
      setCheck1('wrong-input');
      return;
    }else{
       
      setError('');
      setCheck1('right-input');
    }

    if(name.trim() === ''){

      setError('please enter meeting name');
      setCheck2('wrong-input');
    }else{

      setError('');
      setCheck2('right-input');
    }

    const note = {

      notes,
      name,
      email
    }

    const response = await fetch('http://localhost:3001/addNotes',{

        method: 'POST',
        body: JSON.stringify(note),
        headers:{

          'Content-Type':'application/json'
        }
    });

    if(response.ok){

      setError('');
      setNotes('');
      setMail('');
      setShowNote(false);
    }
  };
  
  const ShowNotesDiv = () => {

    setIsNotes(true);
    setBigNotes(false);
  };

  const fetchNotes = async() => {

    const response = await fetch('http://localhost:3001/notes');
    const data = await response.json();
    setNCards([...data]);
    console.log(ncards);
  }

  useEffect(() => {

     fetchNotes();
  },[]);

  const logout = () => {
    
    localStorage.clear();
    navigate('/');
  }

  const ShowBigNotes = (name,notes) => {

    setIsNotes(false);
    setBigNotes(true);
    setTitle(name);
    setContent(notes);
  }

  const AddOneNotes = () => {
      
    setShowNote(!showNote);
    setBigNotes(false);
    setIsNotes(false);
  }
  const Back2Notes = () => {

    setBigNotes(false);
    setIsNotes(true);
  }
  
  const handleRemove = () => {
    setShowConfirmation(true);
  };

  const handleConfirmRemove = async() => {
    setShowConfirmation(false);
    
    const response = await fetch('http://localhost:3001/DeleteNotes',{

    method: 'POST',
    body: JSON.stringify({title}),
    headers: {

      'Content-Type':'application/json'
    }
    });
    
    if(response.ok){

      navigate('/main');
    }
    
  };

  const handleCancelRemove = () => {
    setShowConfirmation(false);
  };
  const handleSave = async () => {
    const response = await fetch('http://localhost:3001/EditNotes', {
      method: 'POST',
      body: JSON.stringify({ title,NewTitle: Newtitle, newNotes: NewNotes ,email}),
      headers: {
        'Content-Type': 'application/json'
      }
    });
  
    if (response.ok) {
      setIsEditing(false);
      fetchNotes();
    }
  };
  let currentTitle=title;
  let currentNotes=content;
  return (
    <>
      <div className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="sidebar-content">
          <div className="sidebar-item">
            <FaHome className="sidebar-icon"  size={30} />
          </div>
          <div className="sidebar-item" onClick={handleAddClick}>
            <RiVideoAddLine className="sidebar-icon"  size={35} />
          </div>
          
          <div className="sidebar-item" onClick={AddOneNotes}>
            <AiFillEdit className="sidebar-icon" size={30} />
          </div>
          <div className="sidebar-item" onClick={ShowNotesDiv}>
            <CgNotes className="sidebar-icon" size={30} />
          </div>
          <div className="logout-container" onClick={logout}>
            <FaSignOutAlt className="sidebar-icon logout-icon" />
            <br />
            <span className="logout-text">Logout</span>
          </div>
        </div>
      </div>
      <div className={`sidebar-toggle ${isOpen ? 'open' : 'close'}`} onClick={toggleSidebar}>
        <div className="line"></div>
        <div className="line"></div>
        <div className="line"></div>
      </div>

     {showAddForm && <AddMeeting onClose={handleAddClick} />}
      {showNote && (
        <div className="note-section">
          <textarea 
          className='notes' 
          placeholder="Enter your note..."
          id={check1}
          onChange={handleNotes}
          value={notes}
          ></textarea>
          <input
          type='text'
          placeholder='Enter Meeting Name'
          className='note-meeting'
          id={check2}
          onChange={handleMail}
          value={name}
          ></input>
          <button className='save-notes' onClick={AddNotes}>Save</button>
          {error && <div className='notes-error'>{error}</div>}
        </div>
      )}

        { isnotes &&
            <div>
              <h1 className='notes-div-heading'>Saved Notes</h1>
            <div className='notes-div'>
                                  
                    {
                      ncards.map((ncard)=>(

                          <Note 
                          name={ncard.name}
                          notes={ncard.notes}
                          showBigNotes={ShowBigNotes}
                          />
                      ))
                    }; 
            </div>
            </div>
        }

        { bigNotes &&
          
           <div className='big-notes-container'>
           <div className='big-notes'>
                  
                  <h1 className='big-notes-heading'>{title}</h1>
                  <p className='big-notes-content'>{content}</p>
                  <div className='big-notes-buttons'>
                   
           <button className='big-buttons' onClick={handleEdit}>
           <AiFillEdit />
           </button>

           {isEditing && 
        <div className='edit-note-section'>
          <input
            className='edit-title'
            value={Newtitle}
            onChange={(e) => setNewTitle(e.target.value)}
          />
          
          <textarea
            className='edit-notes'
            value={NewNotes}
            onChange={(e) => setNewNotes(e.target.value)}
          />
          <div className='edit-buttons'>
            <button className='save-button' onClick={handleSave}>
              Save
            </button>
            <button className='cancel-button' onClick={() => setIsEditing(false)}>
              Cancel
            </button>
          </div>
        </div>
      }

           {!isEditing && <>
           <button className='big-buttons' onClick={Back2Notes}>
           <CgNotes />
           </button>
           <button className='big-buttons' id='bigD' onClick={handleRemove}>
           <AiOutlineDelete />
           </button>
           </>
           }
           
           {showConfirmation && (
            <div className='confirmation-dialog-s'>
            <p className='confirm-text-s'>Are you sure you want to delete this note?</p>
            <div>
            <button onClick={handleConfirmRemove} className='confirm-button1-s'>Yes</button>
            <button onClick={handleCancelRemove} className='confirm-button2-s'>No</button>
            </div>
          </div>
      )}
           </div>
           </div>
           
           </div>

        }
    </>
  );
};

export default Sidebar;
