import '../Start.css';
import Footer from './footer';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Login from './Login.js';

function Start() {
  const navigate = useNavigate();
  const [isLoginFormOpen, setLoginFormOpen] = useState(false);

  const handleLoginButtonClick = () => {
    setLoginFormOpen(true);
  };

  const handleCloseLoginForm = () => {
    setLoginFormOpen(false);
    navigate('/main');
  };

  return (
    <div className="Start-Page">
      <div className="hero-container">
        <div className="background-image"></div>
        <div className="background-overlay"></div>
        <div className="signup-login-container">
          <div className="signup-container">
            <Link to="/signup" className="btn btn-outline-primary signup-button">
              Sign Up
            </Link>
          </div>
          <div className="login-container">
            <button onClick={handleLoginButtonClick} className="btn btn-outline-primary signin-button">
              Sign In
            </button>
          </div>
        </div>
        {isLoginFormOpen && <Login onClose={handleCloseLoginForm} />}
        <div className="hero-content">
          <h1 className="hero-title">Meeting With Clients</h1>
          <p className="hero-description">
            Streamline communication and collaboration with our unified platform. Connect through meetings, team chat,
            whiteboard, phone, and more, all in one comprehensive solution. Make meaningful connections effortlessly and
            boost productivity with our integrated offering.
          </p>
          <button className="hero-button">Meet Now</button>
        </div>
      </div>

      <div className="features-container">
        <div className="feature">
          <div className="feature-icon">
            <i className="fas fa-video"></i>
          </div>
          <h2 className="feature-title">Seamless Video Meetings</h2>
          <p className="feature-description">
            Enjoy high-quality video meetings with smooth audio and video communication, screen sharing, and chat
            functionality.
          </p>
        </div>
        <div className="feature">
          <div className="feature-icon">
            <i className="fas fa-users"></i>
          </div>
          <h2 className="feature-title">Collaborative Workspace</h2>
          <p className="feature-description">
            Collaborate with your team in a virtual workspace. Share documents, brainstorm ideas, and work together in
            real-time.
          </p>
        </div>
        <div className="feature">
          <div className="feature-icon">
            <i className="fas fa-lock"></i>
          </div>
          <h2 className="feature-title">Secure and Reliable</h2>
          <p className="feature-description">
            Rest assured with our secure and reliable platform. Your meetings and data are protected with advanced
            encryption and privacy features.
          </p>
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default Start;
