import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './note.css';
import { AiOutlineDelete } from 'react-icons/ai';
import { FaEye } from 'react-icons/fa';
import { CgSync } from 'react-icons/cg';

function Note(props) {
  const [title, setTitle] = useState(props.name);
  const [notes, setNotes] = useState(props.notes);
  const [showConfirmation, setShowConfirmation] = useState(false);
  
 const navigate = useNavigate();

  const TextLimiter = (text, limit) => {
    if (text && text.split(' ').length > limit) {
      const words = text.split(' ');
      const LimitedText = words.slice(0, limit).join(' ');
      return LimitedText + '...';
    }
    return text;
  };

  const handleRemove = () => {
    setShowConfirmation(true);
  };

  const handleConfirmRemove = async() => {
    setShowConfirmation(false);
    
    const response = await fetch('http://localhost:3001/DeleteNotes',{

    method: 'POST',
    body: JSON.stringify({title}),
    headers: {

      'Content-Type':'application/json'
    }
    });
    
    if(response.ok){

      navigate('/main');
    }
    
  };

  const handleCancelRemove = () => {
    setShowConfirmation(false);
  };

  return (
    <div className='notes-card'>
      <h3 className='notes-title'>{title}</h3>
      <p className='notes-discp'>{TextLimiter(notes, 10)}</p>
      <div className='notes-buttons'>
        <button className='view-button' onClick={() => props.showBigNotes(title, notes)}>
          <FaEye />
        </button>
        <button className='remove-button' onClick={handleRemove}>
          <AiOutlineDelete />
        </button>
      </div>
      {showConfirmation && (
        <div className='confirmation-overlay'>
          <div className='confirmation-dialog'>
            <p className='confirm-text-n'>Are you sure you want to delete this note?</p>
            <div>
            <button onClick={handleConfirmRemove} className='confirm-button1'>Yes</button>
            <button onClick={handleCancelRemove} className='confirm-button2'>No</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Note;