import "./main.css";
import Meeting from "./Meeting";
import React, { useEffect, useState } from "react";
import Sidebar from "./Sidebar";
import logo from "../Assets/user.png";
import EditMeeting from "./EditMeeting";

function Main(props) {
  const [DateTime, setDateTime] = useState(new Date());
  const [currentMeet, setCurrentMeet] = useState("");
 const [editing, setEditing] = useState(false);  
  
  const[newDisc,setNewDisc]=useState("");
  const[newTime,setNewTime]=useState("");
  const[CurrentTitle,getCurrentTitle]=useState("");
  const[newTitle,setNewTitle]=useState("");
  const[newDate,setNewDate]=useState("");
 const StoredData = localStorage.getItem("user");
  const user = JSON.parse(StoredData);
  const reciever = (value) => {
    setCurrentMeet(value);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setDateTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatDate = (date) => {
    const options = { month: "long", day: "numeric" };
    return date.toLocaleDateString(undefined, options);
  };

  const SaveMeeting=async(e)=>{
    setEditing(false); 
    e.preventDefault();
    const response = await fetch('http://localhost:3001/EditMeeting', {
      method: 'POST',
      body: JSON.stringify({
        CurrentTitle,
        newTitle,
        newDisc,
        newTime,
        newDate,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
  };

  return (
    <div className="main-container">
      <div className="upperbar">
        <div className="item-01">
          <div>
            <img src={logo} className="user-icon"></img>
          </div>
          <div>
            <div>
              <h2 className="current-name">{user.name}</h2>
            </div>
            <div>
              <h2 className="current-email">{user.email}</h2>
            </div>
          </div>
        </div>
        <div className="item-02">
          <h1 className="current">Current Meeting: {currentMeet}</h1>
        </div>
        <div id="waqt">
          <h1 className="datetime" id="time">
            {DateTime.toLocaleTimeString()}
          </h1>
          <h1 className="datetime" id="date">
            {formatDate(DateTime)}
          </h1>
        </div>
      </div>
      <div className="notes-panel">
      
        {" "}
        <Sidebar />{" "}
      </div>
      <div className="meetings-panel">
        {props.Components.map((Meetings) => (
          <Meeting
            title={Meetings.title}
            time={Meetings.time}
            discp={Meetings.discp}
            clock={Meetings.clock}
            setEditing={setEditing}
            getCurrentTitle={getCurrentTitle}
            getcurrenttitle={setNewTitle}
            getcurrentdiscp={setNewDisc}
            getcurrenttime={setNewTime}
            getcurrentdate={setNewDate}
            reciever={reciever}
          ></Meeting>
        ))}
      </div>
      {editing && (<div className="form-container">
      <h2>Edit Meeting</h2>
      <form>
        <div className="form-group">
          <label htmlFor="title">Title:</label>
          <input type="text" id="title" name="title" value={newTitle} onChange={(e)=>{setNewTitle(e.target.value)}}/>
        </div>
        <div className="form-group">
          <label htmlFor="description">Description:</label>
          <textarea id="description" name="description" value={newDisc} onChange={(e)=>{setNewDisc(e.target.value)}}></textarea>
        </div>
        <div className="form-group">
          <label >Date:</label>
          <input type="date" id="Date" name="date" value={newDate} onChange={(e)=>{setNewDate(e.target.value)}}/>
        </div>
        <div className="form-group">
          <label htmlFor="time">Time:</label>
          <input type="time" id="time" name="time" value={newTime} onChange={(e)=>{setNewTime(e.target.value)}}/>
        </div>
        <button className="submit-button" type="submit" onClick={(e) => SaveMeeting(e)}>Save Meeting</button>
      </form>
    </div>) 
    }
      
    </div>
    
  );
          
}

export default Main;
