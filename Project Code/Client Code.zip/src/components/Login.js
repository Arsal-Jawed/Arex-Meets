import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './login.css';

const Login = ({ onClose }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errorL,setErrorL] = useState('');
    
    const handleEmailChange = (e) => {
      setEmail(e.target.value);
    };
  
    const handlePasswordChange = (e) => {
      setPassword(e.target.value);
    };
  
    const handleSubmit = async(e) => {
      e.preventDefault();
     if (email.trim() === '' || password.trim() === '') {
      setErrorL("Please enter both email and password");
      return;
    } 
    
    try {
      const savedEmail={
        email
    }
      const SaveEmail = await fetch("http://localhost:3001/addTempEmail", {
        method: "POST",
        body: JSON.stringify(savedEmail),
        headers: {
          "Content-Type": "application/json",
        },
      });
        const response = await fetch('http://localhost:3001/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ email, password })
        });

        if (response.ok) {
          
          const data = await response.json();  
          setEmail('');
          setPassword('');
          setErrorL('');
          localStorage.clear();
          localStorage.setItem("user",JSON.stringify(data));
          onClose();
        } else {
          
          setErrorL('Invalid Email or Password');
        }
      } catch (error) {
        console.error('Error occurred during login:', error);
      }
    }
    
  
    return (
      <div className="login-overlay">
        <form className="login-form" onSubmit={handleSubmit}>
          <label className="login-label">
            Email:
            <input
              type="email"
              placeholder='Enter Email'
              value={email}
              onChange={handleEmailChange}
              className="login-field"
            />
          </label>
          <br />
          <label className="login-label">
            Password:
            <input
              type="password"
              placeholder='Enter Password'
              value={password}
              onChange={handlePasswordChange}
              className="login-field"
            />
          </label>
          <Link to='/forget' className='forget'>Forget Password ?</Link>
          <br />
          <button type="submit" className="login-button">
            Login
          </button>
          {errorL && <div><label className='login-error'>{errorL}</label></div>}
          <div className='NewUser'>
           New User ? <Link to='signup' className='new-link'>Sign Up</Link>
        </div>
        </form>
      </div>
    );
  };
  
  export default Login;