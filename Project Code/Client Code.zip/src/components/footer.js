import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';
import './footer.css';
import card1_img from '../Assets/laptop.jpg';
import pic1 from '../Assets/meet.png';
import pic2 from '../Assets/organize.png';

const Footer = () => {
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <footer className="footer-container" data-aos="fade-up">
      <div className="card-container">
        <div className="card bg-white" data-aos="fade-up">
          <img className="card-img-top" src={pic1} alt="Card 1" />
          <div className="card-body">
            <h5 className="card-title">Meeting Scheduler</h5>
            <p className="card-text">Never miss a meeting with our advanced scheduler. Easily schedule and manage all your meetings with intuitive features and reminders.</p>
            <button className="btn btn-primary">Learn More</button>
          </div>
        </div>
        <div className="card bg-white" data-aos="fade-up">
          <img className="card-img-top" src={pic2} alt="Card 2" />
          <div className="card-body">
            <h5 className="card-title">Organizing Tools</h5>
            <p className="card-text">Stay organized and efficient with our powerful organizing tools. Manage agendas, tasks, and resources to streamline your workflow.</p>
            <button className="btn btn-primary">Learn More</button>
          </div>
        </div>
        <div className="card bg-white" data-aos="fade-up">
          <img className="card-img-top" src={card1_img} alt="Card 3" />
          <div className="card-body">
            <h5 className="card-title">Meeting Notes</h5>
            <p className="card-text">Capture important meeting notes and minutes effortlessly. Our note-taking feature ensures you never miss any valuable information.</p>
            <button className="btn btn-primary">Learn More</button>
          </div>
        </div>
      </div>
      <div className="footer-text" data-aos="fade-up">
        <p>Stay connected with us:</p>
        <div className="social-icons">
          <a href="#"><i className="fab fa-facebook-f"></i></a>
          <a href="#"><i className="fab fa-twitter"></i></a>
          <a href="#"><i className="fab fa-instagram"></i></a>
          <a href="#"><i className="fab fa-linkedin-in"></i></a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
