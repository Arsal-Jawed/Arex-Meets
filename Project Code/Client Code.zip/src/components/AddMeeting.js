import React, { useState } from "react";
import "./addmeeting.css";
import { Link } from "react-router-dom";

const AddMeeting = ({ onClose }) => {
  const [title, setTitle] = useState("");
  const [time, setTime] = useState("");
  const [clock, setClock] = useState("");
  const [discp, setDescription] = useState("");
  const [error1, setError1] = useState("");
  const [error2, setError2] = useState("");
  const [error3, setError3] = useState("");
  const [check1, setCheck1] = useState("right-input");
  const [check2, setCheck2] = useState("right-input");
  const [check3, setCheck3] = useState("right-input");
  const StoredData = localStorage.getItem("user");
  const user = JSON.parse(StoredData);
  const email=user.email;
  const handleTitleChange = (event) => {
    setTitle(event.target.value);
  };
  const handleClockChange = (event) => {
    setClock(event.target.value);
  };
  const handleTimeChange = (event) => {
    setTime(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
 

    if (title.trim() === "") {
      setError1("please enter meeting title");
      setCheck1("wrong-input");
      return;
    } else {
      setError1("");
      setCheck1("right-input");
    }
    if (time.trim() === "") {
      setError2("please select meeting time");
      setCheck2("wrong-input");
      return;
    } else {
      setError2("");
      setCheck2("right-input");
    }
    if (clock.trim() === "") {
      setError2("please select meeting time");
      setCheck2("wrong-input");
      return;
    } else {
      setError2("");
      setCheck2("right-input");
    }
    if (discp.trim() === "") {
      setError3("please enter meeting details");
      setCheck3("wrong-input");
      return;
    } else {
      setError3("");
      setCheck3("right-input");
    }

    const meet = {
      title,
      time,
      discp,
      clock,
      email
    };
    const savedEmail={
        email
    }
    const SaveEmail = await fetch("http://localhost:3001/addTempEmail", {
      method: "POST",
      body: JSON.stringify(savedEmail),
      headers: {
        "Content-Type": "application/json",
      },
    });
    const response = await fetch("http://localhost:3001/add", {
      method: "POST",
      body: JSON.stringify(meet),
      headers: {
        "Content-Type": "application/json",
      },
    });

    onClose();

    setTitle("");
    setTime("");
    setDescription("");
  };

  return (
    <div className="meeting-form">
      <h2>Add Meeting</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="add-label">Title</label>
          <input
            type="text"
            className="add-input"
            id={check1}
            placeholder="Enter Meeting Title"
            value={title}
            onChange={handleTitleChange}
          />
          {error1 && <div className="signup-error">{error1}</div>}
        </div>
        <div className="form-group">
          <label className="add-label">Date</label>
          <input
            type="date"
            className="add-input"
            id={check2}
            placeholder="Enter Meeting Title"
            value={time}
            onChange={handleTimeChange}
          />
          {error2 && <div className="signup-error">{error2}</div>}
        </div>
        <div className="form-group">
          <label className="add-label">Time</label>
          <input
            type="time"
            className="add-input"
            id={check2}
            placeholder="Enter Meeting Title"
            value={clock}
            onChange={handleClockChange}
          />
          {error2 && <div className="signup-error">{error2}</div>}
        </div>
        <div className="form-group">
          <label className="add-label">Description</label>
          <textarea
            value={discp}
            className="add-area"
            id={check3}
            placeholder="Enter Meeting Details (2-3 Lines)"
            onChange={handleDescriptionChange}
          />
          {error3 && <div className="signup-error">{error3}</div>}
        </div>
        <button type="submit" className="add-meeting-button">
          Add Meeting
        </button>
      </form>
    </div>
  );
};

export default AddMeeting;
