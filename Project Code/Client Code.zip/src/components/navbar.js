import React from 'react';
import { Link } from 'react-router-dom';
import './navbar.css';
import pic from '../Assets/ArexMeetsLogo.png';

const Navbar = () => {
  
  const auth = localStorage.getItem("user");

  return (
    <nav className="navbar">
      <div className="container">
        <div className="logo-container">
          <Link to="/" className="navbar-brand">
              <img src={pic} alt="Website Logo"/>
          </Link>
        </div>
        <ul className="nav-menu">
          <li className="nav-item">
            {auth?<Link to="/main" className="nav-link">Home</Link>:<Link to="/" className="nav-link">Home</Link>}
          </li>
          <li className="nav-item">
            <Link to="/about" className="nav-link">About Us</Link>
          </li>
          <li className="nav-item">
            <Link to="/contact" className="nav-link">Contact</Link>
          </li>
          <li className="nav-item">
            <Link to="/more" className="nav-link">More</Link>
          </li>
        </ul>
        <div className="search-buttons-container">
          <form className="search-form">
            <input className="search-input" type="search" placeholder="Search" aria-label="Search" />
            <button className="search-button" type="submit">Search</button>
          </form>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
