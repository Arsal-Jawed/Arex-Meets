import "./meeting.css";
import emailjs from "emailjs-com";
import React, { useState, useEffect , useRef} from "react";
import { useNavigate } from "react-router-dom";
import EditMeeting from "./EditMeeting";
import Main from "./Main";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit } from '@fortawesome/free-solid-svg-icons';

function Meeting(props ) {
  const [title, setTitle] = useState(props.title);
  const [time, setTime] = useState(props.time);
  const [clock, setClock] = useState(props.clock);
  const [discp, setDiscp] = useState(props.discp);
  const [confirmation, setConfirmation] = useState(false);
  const [checkbox, setCheckbox] = useState(false);
  const [email, setEmail] = useState("");
  const [emailer, setEmailer] = useState(false);
  const [error, setError] = useState("");
  const [check, setCheck] = useState("right-input");
  const [editing, setEditing] = useState(false);

  const navigate = useNavigate();
  const StoredData = localStorage.getItem("user");
  const data = JSON.parse(StoredData);
  const EmailSender = data.email;
  const currentDate = new Date().toISOString().slice(0, 10);
  const currentTime = new Date().toLocaleTimeString();
  const [isMeetingDate, setIsMeetingDate] = useState(false);

  function convertTo24HrFormat(time) {
    const [timePart, period] = time.split(" ");
    const [hours, minutes] = timePart.split(":");
    let hour = parseInt(hours);

    if (period && period.toUpperCase() === "PM" && hour < 12) {
      hour += 12;
    } else if (period && period.toUpperCase() === "AM" && hour === 12) {
      hour = 0;
    }

    const hourStr = hour.toString().padStart(2, "0");
    const minuteStr = minutes.toString().padStart(2, "0");

    return `${hourStr}:${minuteStr}`;
  }
  const time12Hr = currentTime;
  const time24Hr = convertTo24HrFormat(time12Hr);
  const audio = new Audio('/src/Assets/sound1.mp3');
  useEffect(() => {
    if ((currentDate === props.time) &&
     (time24Hr === props.clock || time24Hr > props.clock)) {
      setIsMeetingDate(true);
      alert("Meeting, " +title+ " is being held");
      props.reciever(props.title);
    }
  }, [currentDate, props.time]);

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };
  const Invite = () => {
    setEmailer(true);
  };
  const toggleEditing = () => {
    setEditing(!editing);
    props.setEditing(!editing);
    props.getCurrentTitle(props.title);
    props.getcurrenttitle(props.title);
    props.getcurrentdiscp(props.discp);
    props.getcurrenttime(props.clock);
    console.log(props.time);
    props.getcurrentdate(props.time);
  };
  const Send = (e) => {
    if (email.trim() === "") {
      setError("Please enter an email");
      setCheck("wrong-input");
      return;
    } else {
      setError("");
      setCheck("right-input");
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email");
      setCheck("wrong-input");
      return;
    } else {
      setError("");
      setCheck("right-input");
    }

    setEmailer(false);
    console.log(data.name);
    const templateParams = {
      sender: EmailSender,
      reciever: email,
      name: data.name,
      time: time,
      description: discp,
    };

    emailjs.send(
      "service_bwk1mya",
      "template_isvvoc7",
      templateParams,
      "sK_ejLa3HG-WXvIUD"
    );

    setEmail("");
  };

  const CancelMeeting = () => {
    setConfirmation(true);
  };
  const checkBoxHandler = () => {
    setCheckbox(true);
  };
  const ConfirmCancel = async () => {
    setConfirmation(false);
    setIsMeetingDate(false);
    setCheckbox(false);
    props.reciever('');

    const response = await fetch("http://localhost:3001/delete", {
      method: "POST",
      body: JSON.stringify({ title: props.title }),
      headers: {
        "Content-Type": "application/json",
      },
    });
    console.log(props.title);
    navigate("/main");
  };

  const TextLimiter = (text, limit) => {
    if (text && text.split(' ').length > limit) {
      const words = text.split(' ');
      const LimitedText = words.slice(0, limit).join(' ');
      return LimitedText + '...';
    }
    return text;
  };

  return (
    <div className="meeting">
      <div className="info">
      <div className="title-container">
    
  <FontAwesomeIcon className="meeting-edit" onClick={toggleEditing} icon={faEdit} /> 
        <h3 className="title">{title}</h3>
        <h5 className="meeting-time">{time}</h5>
        <h5 className="meeting-time">{clock}</h5>
      </div>
      <div>
      <p className="meeting-detail">{TextLimiter(discp, 25)}</p>
      </div>
      <div className="invite-container">
        <button className="invite-button" onClick={Invite}>
          Invite
        </button>
        <button className="cancel-button" onClick={CancelMeeting}>
          Cancel
        </button>
      </div>
      </div>
      <div className="operations">
      {confirmation && (
        <div className="confirmation">
          <p className="confirm-text">
            Are you sure you want to cancel this meeting?
          </p>
          <button onClick={ConfirmCancel} className="cancel-buttons">
            Yes
          </button>
          <button
            onClick={() => setConfirmation(false)}
            className="cancel-buttons"
          >
            No
          </button>
        </div>
      )}
      {emailer && (
        <div>
          <div className="ask-email">
            <input
              type="text"
              className="email-input"
              id={check}
              placeholder="Enter Email"
              onChange={handleEmailChange}
              value={email}
            ></input>
            <button className="send-email" onClick={Send}>
              Send
            </button>
            <button
              className="cancel-send"
              onClick={() => {
                setEmailer(false);
                setCheck("right-input");
                setError("");
                setEmail("");
              }}
            >
              Cancel
            </button>
          </div>
          <div>{error && <div className="signup-error">{error}</div>}</div>
        </div>
      )}
      {isMeetingDate && 
          <p className="meeting-text">  The meeting is being held.  <div className="checkbox"><input type="checkbox" onChange={checkBoxHandler}>
          </input>  Mark as done? </div>    </p>}
      {checkbox && (
        <div className="confirmation">
          <p className="confirm-text">
            It will delete your meeting !  Are you sure? 
          </p>
          <button onClick={ConfirmCancel} className="cancel-buttons">
            Yes
          </button>
          <button
            onClick={() => setCheckbox(false)}
            className="cancel-buttons"
          >
            No
          </button>
        </div>
      )}
      </div>
    </div>
  );
}

export default Meeting;
