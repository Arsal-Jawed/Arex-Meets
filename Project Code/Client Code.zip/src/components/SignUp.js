import './signup.css';
import '../Start.css';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function SignUp() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [repass, setRepass] = useState('');
  const [organize, setOrganize] = useState('');
  const [type, setType] = useState('');
  const [error1, setError1] = useState('');
  const [error2, setError2] = useState('');
  const [error3, setError3] = useState('');
  const [error4, setError4] = useState('');
  const [error5, setError5] = useState('');
  const [error6, setError6] = useState('');
  const [check1, setCheck1] = useState('right-input');
  const [check2, setCheck2] = useState('right-input');
  const [check3, setCheck3] = useState('right-input');
  const [check4, setCheck4] = useState('right-input');
  const [check5, setCheck5] = useState('right-input');
  const [check6, setCheck6] = useState('right-input');

  const navigate = useNavigate();

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePassChange = (e) => {
    setPass(e.target.value);
  };

  const handleRePassChange = (e) => {
    setRepass(e.target.value);
  };

  const handleOrganize = (e) => {
    setOrganize(e.target.value);
  };

  const handleType = (e) => {
    setType(e.target.value);
  };

  const addUser = async (event) => {
    event.preventDefault();
    
    
        if (name.trim() === '') {
          setError1('Please enter a username');
          setCheck1('wrong-input');
          return;
        }else{
  
          setError1('');
          setCheck1('right-input');
        }

        if (pass.trim() === '') {
            setError2('Please enter a password');
            setCheck2('wrong-input');
            return;
          }else if (pass.length < 8 || !/[!@#$%^&*(),.?":{}|<>]/.test(pass)) {
            setError2('Should contains 8 and \n atleast 1 special character');
            setCheck2('wrong-input');
            return;
          }else{
    
            setError2('');
            setCheck2('right-input');
          }
    
          if (repass.trim() === ''){
            setError3('Please re-enter your password');
            setCheck3('wrong-input');
            return;
          }else{
    
            setError3('');
            setCheck3('right-input');
          }
    
          if (pass !== repass) {
            setError3('Passwords do not match');
            setCheck3('wrong-input');
            return;
          } else {
            setError3('');
            setCheck3('right-input');
          }
    
        if (email.trim() === '') {
          setError4('Please enter an email');
          setCheck4('wrong-input');
          return;
        }else{
  
          setError4('');
          setCheck4('right-input');
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
        setError4('Please enter a valid email');
        setCheck4('wrong-input');
        return;
        } else {
        setError4('');
        setCheck4('right-input');
        }
        if (organize.trim() === ''){

            setError5('Please Enter Organization Name');
            setCheck5('wrong-input');
            return;

        }else{

            setError5('');
            setCheck5('right-input');
        }
        if (type.trim() === ''){

            setError6('Please Enter Organization Type');
            setCheck6('wrong-input');
            return;

        }else{

            setError6('');
            setCheck6('right-input');
        }
    
        const user = {
          name,
          email,
          pass,
          organize,
          type
        }
    
        const response = await fetch('http://localhost:3001/', {
          method: 'POST',
          body: JSON.stringify(user),
          headers: {
            'Content-Type': 'application/json'
          }
        });
        
        console.log(user);
    
        setName('');
        setEmail('');
        setPass('');
        setRepass('');
        setOrganize('');
        setType('');
        setError1('');
        setError2('');
        setError3('');
        setError4('');
        setError5('');
        setError6('');
  
        localStorage.setItem("user",JSON.stringify(user));
        
        navigate('/');
  
      }
      
  return (
    <div className="signup-container">
      <div className="signup-image"></div>
      <div className="signup-overlay"></div>
      <div className="signup-content">
        <div className="signup-text">
          <h1 className="signup-header">
            Just a Step Away from a New Innovation of your Projects
          </h1>
          <p className="signup-para">
            Experience seamless collaboration with our cutting-edge Online Meeting website.
            Connect with colleagues, clients, and friends effortlessly from anywhere in the world.
            Enjoy high-quality audio and video, easy screen sharing, and interactive features.
            Sign up now and elevate your virtual meetings to the next level.
          </p>
        </div>
        <div className="signup-box"> 
              <form onSubmit={addUser}>
                <div className="signup-input">
                  <div className="signup-input-unit">
                    <label className="signup-label">Username</label>
                    <input
                      type="text"
                      className={`signup-field`}
                      id={check1}
                      placeholder="Enter Username"
                      value={name}
                      onChange={handleNameChange}
                    />
                    {error1 && <div className="signup-error">{error1}</div>}
                  </div>
                  <div className='signup-input-unit'>
                    <label className='signup-label'>Password</label>
                    <input
                      type='password'
                      className={`signup-field`}
                      id={check2}
                      placeholder='Enter Password'
                      value={pass}
                      onChange={handlePassChange}
                    />
                    {error2 && <div className='signup-error'>{error2}</div>}
                  </div>
                  <div className='signup-input-unit'>
                    <label className='signup-label'>Re-Enter Password</label>
                    <input
                      type='password'
                      className={`signup-field`}
                      id={check3}
                      placeholder='Re-Enter Password'
                      value={repass}
                      onChange={handleRePassChange}
                    />
                    {error3 && <div className='signup-error'>{error3}</div>}
                  </div>
                  <div className='signup-input-unit'>
                    <label className='signup-label'>Email</label>
                    <input
                      type='text'
                      className={`signup-field`}
                      id={check4}
                      placeholder='Enter Your Email'
                      value={email}
                      onChange={handleEmailChange}
                    />
                    {error4 && <div className='signup-error'>{error4}</div>}
                  </div>
                  <div className='signup-input-unit'>
                    <label className='signup-label'>Organization</label>
                    <input
                      type='text'
                      className={`signup-field`}
                      id={check5}
                      placeholder='Organization Name'
                      value={organize}
                      onChange={handleOrganize}
                    />
                    {error5 && <div className='signup-error'>{error5}</div>}
                  </div>
                  <div className='signup-input-unit'>
                    <label className='signup-label'>Category</label>
                    <input
                      type='text'
                      className={`signup-field`}
                      id={check6}
                      placeholder='Organization Type'
                      value={type}
                      onChange={handleType}
                    />
                    {error6 && <div className='signup-error'>{error6}</div>}
                  </div>
                </div>
                <div className='signup-button-container'>
                  <button id='signup-button' type='submit'>Sign Up</button>
                  <Link to='/'><button id='cancel-signup'>Cancel</button></Link>
                </div>
              </form>
            </div>
          </div>
        </div>
      );
    }

    export default SignUp;