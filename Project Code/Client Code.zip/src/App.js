import React,{useState,useEffect} from 'react';
import Navbar from './components/navbar';
import Start from './components/Start';
import SignUp from './components/SignUp';
import Main from './components/Main';
import Forget from './components/Forget';
import './Start.css';
import {Routes, Route} from 'react-router-dom';

const App = () => {

  const [cards,setCards] = useState([]);

  const fetchComponents = async() =>{

    const response = await fetch('http://localhost:3001/add');
    const data = await response.json();
    setCards([...data]);
  }

  useEffect(() => {
    fetchComponents();
}, []);

  return (
    <div className="app">
      <Navbar />
      <Routes>
           <Route path='/' element={<Start />}/>
           <Route path='/about' element={<h1>About Us Page</h1>}/>
           <Route path='/contact' element={<h1>Contact Us Page</h1>}/>
           <Route path='/More' element={<h1>More of Our Projects Links</h1>}/>
           <Route path='/signup' element={<SignUp />}/>
           <Route path='/forget' element={<Forget />}/>
           <Route path='/main' element={<Main Components={cards}/>}/>
      </Routes>
      
      
    </div>
  );
};

export default App;
