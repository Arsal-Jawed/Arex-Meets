const express = require('express');
const {MongoClient} = require('mongodb');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const url = 'mongodb://localhost:27017';
const database = 'Meet';

app.use(cors());
app.use(bodyParser.json());

const connectDB = async () => {
    try {
      const client = new MongoClient(url, {
        useUnifiedTopology: true,
      });

    await client.connect();
    
    const db = client.db(database);
    const collection = db.collection('user');
    app.post('/login', async (req, res) => {
        const { email, password } = req.body;
  
        const user = await collection.findOne({ email });
  
        if (!user || user.pass === password) {
          res.status(200).json(user);
          
        } else {
             
            res.status(401).json({ success: false, message: 'Invalid Email or Password' });
        }
      });
  
      app.post('/', async (req, res) => {
        try {
          const client = await MongoClient.connect(url);
          const db = client.db(database);
          const collection = db.collection('user');
          const document = req.body;
          await collection.insertOne(document);
          res.json(document);
          client.close();
        } catch (error) {
          console.error('Error connecting to MongoDB:', error);
          res.status(500).json({ error: 'Error connecting to MongoDB' });
        }
      });
      
      app.get('/add', async(req,res) => {

        const client = await MongoClient.connect(url);
        const db = client.db(database);
        const collection = db.collection('meeting');
        const temp = db.collection('temp');
        const uniqueEmails = await temp.distinct('email');
        const documents = await collection.find({ email: { $in: uniqueEmails } }).toArray();
        res.json(documents);
        client.close();
      });

      app.post('/add', async(req,res) => {

        const client = await MongoClient.connect(url);
        const db = client.db(database);
        const collection = db.collection('meeting');
        const document = req.body;
        await collection.insertOne(document);
        res.json(document);
        client.close();
      });
      
      app.post('/delete', async (req, res) => {
        const client = await MongoClient.connect(url);
        const db = client.db(database);
        const collection = db.collection('meeting');
        const document = req.body.title;
      
        try {
          const result = await collection.deleteOne({ title: document });
      
          if (result.deletedCount === 1) {
            console.log(`Meeting with title "${document}" deleted successfully.`);
            res.json({ message: `Meeting with title "${document}" deleted successfully.` });
          } else {
            console.log(`Meeting with title "${document}" not found.`);
            res.status(404).json({ error: `Meeting with title "${document}" not found.` });
          }
        } catch (error) {
          console.error('Error deleting meeting:', error);
          res.status(500).json({ error: 'An error occurred while deleting the meeting.' });
        } finally {
          client.close();
        }
      });

      app.post('/fmail',async(req,res) => {

          const collection = db.collection('user');
          const {fmail} = req.body;
          const user = await collection.findOne({email:fmail});
          if(user){

            res.status(200).json();
          }else{

            res.status(401).json();
          }
      });

      app.post('/reset',async(req,res) => {

         const collection = db.collection('user');
         const {fmail,pass1} = req.body;
         const user = await collection.updateOne({email:fmail},{$set:{pass:pass1}});
         res.status(200).json();
         console.log("Password Updated Successfully");
      });

      app.post('/addNotes', async(req,res) => {

         const collection = db.collection('notes');
         const notes = req.body;
         console.log(notes);
         await collection.insertOne(notes);
         res.status(200).json();
      });

      app.get('/notes', async(req,res) => {

         const collection = db.collection('notes');
         const temp = db.collection('temp');
         const email = await temp.distinct('email');
         const note = await collection.find({email:{$in: email}}).toArray();
         res.json(note);
      });

      app.post('/DeleteNotes', async(req,res) => {

          const collection = db.collection('notes');
          const {title} = req.body;
          await collection.deleteOne({name: title});
          res.status(200).json();
      });
      app.post('/EditNotes', async (req, res) => {
        try {
          const client = await MongoClient.connect(url);
          const db = client.db(database);
          const collection = db.collection('notes');
          const { title,NewTitle, newNotes ,email} = req.body;
          const result = await collection.updateOne(
            { name: title },
            { $set: { notes: newNotes, name:NewTitle} }
          );
          console.log(title,NewTitle,newNotes,email)
          res.status(200).json(result);
        } catch (error) {
          console.error('Error updating notes:', error);
          res.status(500).json({ error: 'An error occurred while updating notes.' });
        }
      });
      app.post('/EditMeeting', async (req, res) => {
        try {
          const { CurrentTitle, newTitle, newDisc, newDate, newTime } = req.body;
          const client = await MongoClient.connect(url);
          const db = client.db(database);
          const collection = db.collection('meeting');
          const result = await collection.updateOne(
            { title: CurrentTitle }, 
            {
              $set: {
                title: newTitle,
                discp: newDisc,
                time: newDate,
                clock: newTime,
              },
            }
          );
  
        } catch (error) {
          console.error('Error updating meeting:', error);
          res.status(500).json({ error: 'An error occurred while updating the meeting.' });
        }
      });
      app.post('/addTempEmail', async(req,res) => {

        const client = await MongoClient.connect(url);
        const db = client.db(database);
        const collection = db.collection('temp');
        const document = req.body;
        console.log(document);
        await collection.deleteMany();
        await collection.insertOne(document);
        res.json(document);
        client.close();
      });
      
      app.listen(3001, () => {
        console.log('Server Started');
      });
    } catch (error) {
      console.error(error);
    }
}
    connectDB();